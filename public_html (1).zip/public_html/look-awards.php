<?
require_once "connect.php"
?>
<!DOCTYPE HTML>
<html>
 <head>
    <meta charset="UTF-8">
    <title>Пример веб-страницы</title>
    <link rel="stylesheet" href="../static/css/Main.css">


 </head>
 <body>
        <div class="Top-bar">
            <a href="Main.html"><img src=../images/logored.png class="logo"></a>
        </div>
            <div class="nav-buttons">
                <a role="button" class="category-button" href="index.php">Оформить сделку</a>
                <a role="button" class="category-button" href="deal-history.php">История сделок</a>
                <a role="button" class="category-button" href="look-awards.php">Просмотр начисленной премии</a>
            </div>
            <div class="Block-deal">
                <form action="" method="get">
                </form>
           
                <form action="" method="get">
                    <table id="award-table">
                        <thead>
                          <tr>
                            <th>ID сделки</th>
                            <th>Дата заключения договора</th>
                            <th>Адрес объекта сделки</th>
                            <th>Тип сделки</th>
                            <th>Сумма сделки</th>
                            <th>Премия</th>
                          </tr>
                        </thead>
                    </table>
                        <table>
                        <tbody id="tbody-award">
                         <?
                        $deals=mysqli_query($conn,"SELECT * FROM `deals_history`");
                        $deals=mysqli_fetch_all($deals);
                        foreach($deals as $deal){
                            ?>
                            <tr>
                                <td><?=$deal[0]?></td>  <!--#deal_id -->
                                <td><?=$deal[1]?></td> <!-- #date-->
                                <td><?=$deal[5]?></td> <!--#adres -->
                                <td><?=$deal[2]?></td> <!--#deal_typy -->
                                <td><?=$deal[3]?>(₽)</td> <!--#deal_price -->
                            </tr>
                            <?
                        }
                        ?>
                        </tbody>
                    </table>
                    <input id="award-p" type="text" readonly>тестовое сообщение
                </form>
            </div>
</body>
</html>