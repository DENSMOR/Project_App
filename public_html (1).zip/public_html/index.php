<!DOCTYPE HTML>
<html>
 <head>
    <meta charset="UTF-8">
    <title>Пример веб-страницы</title>
    <link rel="stylesheet" href="/static/css/Main.css">


 </head>
 <body>
            <div class="Top-bar">
                <a href="Main.html"><img src=../images/logored.png class="logo"></a>
            </div>
            <div class="nav-buttons">
                <a role="button" class="category-button" href="index.php">Оформить сделку</a>
                <a role="button" class="category-button" href="deal-history.php">История сделок</a>
                <a role="button" class="category-button" href="look-awards.php">Просмотр начисленной премии</a>
            </div>
            <div class="Block-deal">
                <div class="All-deal">
                    <form action="http://denisGay.com" method="post">
                        <div class="Type-deal"> 
                            <span class="deal-title">Тип сделки<span>
                            <label class="container">Договор найма
                                <input type="radio" checked="checked" name="radio">
                                <span class="checkmark"></span>
                            </label>
                            <label class="container">Договор покупки
                                <input type="radio" name="radio">
                                <span class="checkmark"></span>
                            </label>
                            <label class="container">Договор аренды
                                <input type="radio" name="radio">
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-deal">
                            <span class="details">id клиента: </span>
                            <input type="text" placeholder="Введите id клиента" name="id" maxlength="10">
                        </div>
                        <div class="Type-status">
                            <span class="status-title">Статус сделки<span>
                            <label class="container-1">В процесе
                                <input type="radio" checked="checked" name="radio-1">
                                <span class="checkmark-1"></span>
                            </label>
                            <label class="container-1">Завершена
                                <input type="radio" name="radio-1">
                                <span class="checkmark-1 "></span>
                            </label>
                        </div>
                        <div class="form-deal">
                            <span class="details">Сумма сделки: </span>
                            <input type="text" placeholder="Введите сумму сделки"name="Sum">
                        </div>
                        <div class="form-deal">
                            <span class="details">Адрес сделки: </span>
                            <input type="text" placeholder="Введите адрес сделки" name="Adress">
                        </div>
                        <div class="form-deal">
                            <span class="details">Дата заключения договора: </span>
                            <input type="text" placeholder="Введите дату заключения" name="Data">
                        </div>
                        <div class="form-dop">
                            <span class="details">Дополнительная информация: </span>
                            <input type="text" name="info"/>
                        </div>
                            <div class="form-save">
                            <input type="submit" value="Сохранить сделку" />
                        </div>
                    </form>
                </div>
            </div>
</body>
</html>
